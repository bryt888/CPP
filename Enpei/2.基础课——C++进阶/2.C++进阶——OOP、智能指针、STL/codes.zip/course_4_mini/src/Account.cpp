#include "Account.h"
#include <iostream>

void Account::set_name(std::string name){
    this->name = name; // this指针指向当前对象
}
std::string Account::get_name(){
    return name;
}
bool Account::deposit(double amount){
    balance += amount;
    std::cout << name << "刚存入" << amount << "元，现在余额为" << balance << "元" << std::endl;
    return true;
}
bool Account::withdraw(double amount){
    if (balance >= amount){
        balance -= amount;
        std::cout << name << "刚取出" << amount << "元，现在余额为" << balance << "元" << std::endl;
        return true;
    } else {
        std::cout << name << "余额不足，取款失败" << std::endl;
        return false;
    }
}

