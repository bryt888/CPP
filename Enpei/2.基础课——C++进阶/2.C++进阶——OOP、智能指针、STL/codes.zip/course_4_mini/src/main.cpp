#include <iostream>
#include <string>
#include <vector>
#include "Account.h" // 引入头文件

using namespace std;


int main()
{
    Account alice_account;
    alice_account.set_name("Alice's account"); // 设置名称
    alice_account.set_balance(1000.0); // 设置余额

    cout << alice_account.get_name() << "的余额为" << alice_account.get_balance() << "元" << endl;

    alice_account.deposit(200.0);
    alice_account.withdraw(500.0);
    alice_account.withdraw(1500.0);

    return 0;
}