#ifndef ACCOUNT_H
#define ACCOUNT_H
#include <string>

class Account
{
private:
    // 属性
    std::string name {"None"};
    double balance {0.0};

public:
    // 方法

    // 设置余额
    void set_balance(double amount){balance = amount;};
    // 获取余额
    double get_balance(){return balance;};

    // 设置名称
    void set_name(std::string name);
    // 获取名称
    std::string get_name();

    // 存款
    bool deposit(double amount);
    // 取款
    bool withdraw(double amount);
};


#endif // ACCOUNT_H