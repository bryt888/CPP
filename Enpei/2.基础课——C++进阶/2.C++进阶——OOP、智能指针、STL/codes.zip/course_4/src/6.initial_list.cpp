#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Account
{
private:
    // 属性
    std::string name {"account"};
    double balance {0.0};
public:
    // 打印信息
    void printInfo();
    // 构造函数，初始化参数
    Account(string name, double balance);
   
};

void Account::printInfo(){
    cout << "name: " << name << ", balance: " << balance << endl;
}
// 构造函数内部初始化参数
Account::Account(string name, double balance){
    this->name = name;
    this->balance = balance;
}

int main()
{

    Account *mark_account = new Account("Mark's account", 1000.0);
    mark_account->printInfo(); // 打印信息
    delete mark_account;


    return 0;
}