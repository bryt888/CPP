#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Account
{
private:
    // 属性
    std::string name {"account"};
    double balance {0.0};
public:
    // 打印信息
    void printInfo();
    // 构造函数，初始化参数
    Account();
    Account(string name);
    Account(string name, double balance);
   
};

void Account::printInfo(){
    cout << "name: " << name << ", balance: " << balance << endl;
}

// 构造函数内部初始化参数
// Account::Account(){
//     name = "None";
//     balance = 0.0;
// }
// Account ::Account(string name){
//     this->name = name;
//     balance = 0.0;
// }
// Account::Account(string name, double balance){
//     this->name = name;
//     this->balance = balance;
// }

// 构造函数初始化列表
Account::Account()
    :name{"none"}, balance{0.0}{
        
    }
Account::Account(string name)
    :name{name}, balance{0.0}{
        
    }

Account::Account(string name, double balance)
    :name{name}, balance{balance}{
        
    }

    

int main()
{

    Account alice_account;
    alice_account.printInfo(); // 打印信息

    Account jobs_account {"Jobs's account"};
    jobs_account.printInfo(); 

    Account bill_account {"Bill's account", 1000.0};
    bill_account.printInfo(); 


    return 0;
}