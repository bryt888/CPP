#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Account
{
private:
    // 属性
    string name {"account"};
    double balance {0.0};
public:
    string getName() {return name;} // 获取name
    double getBalance() {return balance;} // 获取balance
    // 构造函数
    Account(string name = "none", double balance = 0.0);
    // 析构函数
    ~Account();
    // 拷贝构造函数
    Account(const Account &source);
};

Account::Account(string name, double balance)
    :name {name}, balance {balance}
    {
        cout << "2个参数的构造函数被调用，name：" << name << endl;
    }

Account::~Account()
{
    cout << "析构函数被调用，name：" << name << endl;
}

// 拷贝构造函数：根据已存在对象的属性来更新新对象的属性（name,balance）
Account::Account(const Account &source)
    :name {source.name}, balance {source.balance} // 初始化列表
    {
        cout << "拷贝构造函数被调用，是" << source.name << "的拷贝" << endl;
    }
// 打印账户信息
void printAccountInfo(Account acc)
{
    cout << acc.getName() << "的余额是：" << acc.getBalance() << endl;
}
int main()
{
    // 1.值传递的方式给函数传递参数
    // Account alice_account;
    // printAccountInfo(alice_account);
    
    // 2.基于已存在的对象创建新的对象
    Account alice_account {"Alice's account", 1000.0};
    Account new_account {alice_account}; // 拷贝构造函数被调用
    return 0;
}