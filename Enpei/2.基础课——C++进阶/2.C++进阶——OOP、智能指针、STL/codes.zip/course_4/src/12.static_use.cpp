#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Account
{
private:
    // 属性
    string name {"account"};
    double balance {0.0};
    static int num_accounts;
public:
    static int get_num_accounts();
    Account(string name, double balance);
    ~Account();
};

int Account::num_accounts {0};

Account::Account(string name, double balance)
    :name{name}, balance{balance}{
        num_accounts++;
    }

Account::~Account()
{
    num_accounts--;
}

int Account::get_num_accounts() // 不需要使用static关键字
{
    // 静态成员方法只能访问静态成员变量
    // name = "test";
    return num_accounts;
}
int main()
{
    cout << Account::get_num_accounts() << endl;
    Account alice_account {"Alice's account", 1000.0};
    cout << alice_account.get_num_accounts() << endl;
    Account bob_account {"Bob's account", 2000.0};
    cout << Account::get_num_accounts() << endl;
    
    {
        Account test_account {"test", 100.0};
        cout << Account::get_num_accounts() << endl;
    }
    cout << Account::get_num_accounts() << endl;
    return 0;
}