#include <iostream>
using namespace std;


int main()
{
    
    int *ptr;
    cout << "ptr的地址是: " << &ptr << endl;
    cout << "ptr的值是: " << ptr << endl;

    return 0;
}