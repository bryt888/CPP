# python 代码测试

# 计算 1+2+3+4+5 的和
sum = 0;
for i in range(5):
    sum += i

# 打印结果
print(sum);
    
