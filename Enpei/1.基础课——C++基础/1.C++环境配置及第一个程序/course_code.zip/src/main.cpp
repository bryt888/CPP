#include <iostream>
using namespace std;

int main(){
    
    // 计算 1+2+3+4+5
    int sum {0};
    for (int i {0}; i < 5; i++){
        sum += i;
    }
    // 输出结果
    cout << sum << endl;
    return 0;
    
}