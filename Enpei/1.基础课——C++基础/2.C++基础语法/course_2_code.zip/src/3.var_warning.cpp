#include <iostream>
using namespace std;
//  未初始化警告
int main()
{
    int age;
    cout << age << endl;
    return 0;
}