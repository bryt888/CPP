#include <iostream>
using namespace std;

int main()
{
    cout << "Hello Main Function" << endl;
    return 0;
}

