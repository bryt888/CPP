#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

int main()
{
    // int student_scores [] {100, 98, 90, 86, 84}; // 初始化数组
    // for (auto score: student_scores)
    //     cout << score << endl;





    // // 计算平均温度
    // vector <double>  temps {23.1,22.9,19.3,23.2}; // 初始化vector
    // double temp_average {};
    // double temp_total {};

    // for (auto temp: temps)
    //     temp_total += temp;

    // if (temps.size() != 0)
    //     temp_average = temp_total / temps.size();
    
    // // 设置精度
    // cout << fixed << setprecision(1);
    // cout << "平均温度：" << temp_average << endl;




    // // 初始化的列表
    // for (auto i: {1,2,3,4,5,6,7,8,9,10})
    //     cout << i << endl;

    // return 0;


    // 遍历string 字符串
    for (auto c: "This is a test")
        cout << c;
    cout << endl;
}