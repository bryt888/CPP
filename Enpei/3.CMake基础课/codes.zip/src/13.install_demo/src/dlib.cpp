#include "dlib.h"
#include <iostream>

void dlib_test()
{
    std::cout << "动态库的dlib_test函数被调用" << std::endl;
}