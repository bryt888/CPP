#include "slib.h"
#include <iostream>

void slib_test()
{
    std::cout << "静态库的slib_test函数被调用" << std::endl;
}