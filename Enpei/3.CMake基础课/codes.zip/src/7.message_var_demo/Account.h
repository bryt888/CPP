#ifndef ACCOUNT_H
#define ACCOUNT_H

class Account
{
private:
    /* data */
public:
    Account(/* args */);
    ~Account();
};


#endif // ACCOUNT_H