#include "dlib.h"
#include <iostream>

int main()
{
    std::cout << "在main函数中" << std::endl;
    dlib_demo();
    return 0;
}