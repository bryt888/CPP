#include <iostream>
#include "dlib.h"

void dlib_demo()
{
    std::cout << "动态库：dlib_demo()函数内部调用" << std::endl;
}