#include "dlib.h"
#include <iostream>

void dlib_test(){
    std::cout << "动态库dlib_test()被调用" << std::endl;
}