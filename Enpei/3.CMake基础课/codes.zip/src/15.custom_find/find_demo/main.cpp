#include <iostream>
#include "dlib.h"

int main(){
    std::cout << "main函数被调用" << std::endl;
    dlib_test();
    return 0;
}