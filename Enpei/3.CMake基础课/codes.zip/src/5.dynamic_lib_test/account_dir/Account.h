#ifndef Account_H
#define Account_H

class Account
{
private:
    /* data */
public:
    Account(/* args */);
    ~Account();
};


#endif // Account_H