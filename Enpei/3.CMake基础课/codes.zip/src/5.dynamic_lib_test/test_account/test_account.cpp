#include <iostream>
#include "Account.h"

int main()
{
    Account alice_account;
    std::cout << "test Account 的main函数" << std::endl;
    return 0;
}